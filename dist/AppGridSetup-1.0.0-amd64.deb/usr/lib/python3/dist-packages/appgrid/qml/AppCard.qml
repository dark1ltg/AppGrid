import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import "."

Item {
    id: card
    signal clicked()

    property bool thumbOk: fallback.status === Image.Ready
    property bool iconOk: iconShot.status === Image.Ready
    property bool isShot: thumb !== "" && thumb !== icon

    Rectangle {
        anchors.fill: parent
        radius: 14
        color: "#1C2330"
        border.color: installed ? "#3D9B93" : "#2A3344"
        border.width: installed ? 2 : 1

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: 10
            spacing: 8

            Rectangle {
                id: frame
                Layout.fillWidth: true
                Layout.fillHeight: true
                Layout.minimumHeight: 128
                Layout.preferredHeight: 128
                radius: 10
                color: "#10141C"
                clip: true

                Image {
                    id: fallback
                    anchors.fill: parent
                    anchors.margins: isShot ? 0 : 18
                    source: thumb
                    fillMode: isShot ? Image.PreserveAspectCrop : Image.PreserveAspectFit
                    asynchronous: true
                    cache: true
                    visible: thumb !== "" && thumbOk
                }

                Image {
                    id: iconShot
                    anchors.fill: parent
                    anchors.margins: 18
                    source: icon
                    fillMode: Image.PreserveAspectFit
                    asynchronous: true
                    visible: !thumbOk && iconOk
                }

                Rectangle {
                    anchors.fill: parent
                    visible: !thumbOk && !iconOk
                    gradient: Gradient {
                        GradientStop { position: 0.0; color: Qt.lighter(accent, 1.18) }
                        GradientStop { position: 1.0; color: accent }
                    }

                    Column {
                        anchors.centerIn: parent
                        spacing: 6
                        Text {
                            anchors.horizontalCenter: parent.horizontalCenter
                            text: initial
                            color: "#FFFFFF"
                            font.family: Fonts.sans
                            font.pixelSize: Fonts.heading
                            font.weight: Fonts.bold
                        }
                        Text {
                            anchors.horizontalCenter: parent.horizontalCenter
                            text: name
                            color: "#F2F6FB"
                            font.family: Fonts.sans
                            font.pixelSize: Fonts.chip
                            font.weight: Fonts.medium
                        }
                    }
                }

                Rectangle {
                    visible: controller.showSourceBadges
                    anchors.left: parent.left
                    anchors.top: parent.top
                    anchors.margins: 8
                    width: badge.implicitWidth + 14
                    height: 22
                    radius: 11
                    color: "#CC12151C"
                    z: 2
                    Text {
                        id: badge
                        anchors.centerIn: parent
                        text: backend === "flatpak" ? "FLATPAK" : "APT"
                        color: "#F4F7FB"
                        font.family: Fonts.mono
                        font.pixelSize: Fonts.monoSize
                        font.weight: Fonts.regular
                    }
                }

                Rectangle {
                    visible: hasUpdate
                    anchors.right: parent.right
                    anchors.top: parent.top
                    anchors.margins: 8
                    width: 70
                    height: 22
                    radius: 11
                    color: "#D98A2B"
                    z: 2
                    Text {
                        anchors.centerIn: parent
                        text: "UPDATE"
                        color: "white"
                        font.family: Fonts.sans
                        font.pixelSize: Fonts.badge
                        font.weight: Fonts.bold
                    }
                }
            }

            Label {
                text: name
                color: "#F2F6FB"
                font.family: Fonts.sans
                font.pixelSize: Fonts.appName
                font.weight: Fonts.medium
                elide: Text.ElideRight
                Layout.fillWidth: true
            }

            Label {
                visible: rating > 0
                text: "★ " + Number(rating).toFixed(1)
                color: "#E8C547"
                font.family: Fonts.sans
                font.pixelSize: Fonts.rating
                font.weight: Fonts.regular
            }

            Label {
                text: summary
                color: "#9AA8BA"
                font.family: Fonts.sans
                font.pixelSize: Fonts.description
                font.weight: Fonts.regular
                wrapMode: Text.WordWrap
                maximumLineCount: 2
                elide: Text.ElideRight
                Layout.fillWidth: true
            }

            Label {
                visible: installed
                text: hasUpdate ? "Installed · update available" : "Installed"
                color: "#6FCFC6"
                font.family: Fonts.sans
                font.pixelSize: Fonts.status
                font.weight: Fonts.medium
            }
            Label {
                visible: !installed && controller.showSourceBadges
                text: origin
                color: "#7E8B9A"
                font.family: Fonts.sans
                font.pixelSize: Fonts.status
                font.weight: Fonts.regular
            }
        }
    }

    MouseArea {
        anchors.fill: parent
        cursorShape: Qt.PointingHandCursor
        onClicked: card.clicked()
    }
}
