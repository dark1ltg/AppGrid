import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtQuick.Controls.Material
import "."

Page {
    id: page
    signal back()
    background: Rectangle { color: "#12151C" }

    Dialog {
        id: removeConfirm
        title: "Remove this app?"
        modal: true
        standardButtons: Dialog.Cancel | Dialog.Ok
        font.family: Fonts.sans
        font.pixelSize: Fonts.button
        font.weight: Fonts.medium
        Label {
            text: controller.selectedCopyCount > 1
                  ? "Remove " + controller.selectedName + "? Every installed copy will be removed."
                  : "Remove " + controller.selectedName + "?"
            wrapMode: Text.WordWrap
            width: 420
            font.family: Fonts.sans
            font.pixelSize: Fonts.settings
            font.weight: Fonts.regular
        }
        onOpened: {
            var ok = standardButton(Dialog.Ok)
            if (ok)
                ok.text = "Remove"
        }
        onAccepted: controller.removeSelected()
    }

    ColumnLayout {
        anchors.fill: parent
        anchors.margins: 28
        spacing: 18

        RowLayout {
            Button {
                text: "Back"
                font.family: Fonts.sans
                font.pixelSize: Fonts.button
                font.weight: Fonts.medium
                onClicked: page.back()
            }
            Item { Layout.fillWidth: true }
            Button {
                visible: controller.selectedHasUpdate
                text: "Update"
                font.family: Fonts.sans
                font.pixelSize: Fonts.button
                font.weight: Fonts.medium
                enabled: !controller.busy
                onClicked: controller.updateSelected()
            }
            Button {
                visible: controller.selectedCanInstall
                text: "Install"
                font.family: Fonts.sans
                font.pixelSize: Fonts.button
                font.weight: Fonts.medium
                enabled: !controller.busy && controller.selectedUid !== ""
                Material.background: "#2A6F6A"
                onClicked: controller.installSelected()
            }
            Button {
                visible: controller.selectedCanRemove
                text: "Remove"
                font.family: Fonts.sans
                font.pixelSize: Fonts.button
                font.weight: Fonts.medium
                enabled: !controller.busy && controller.selectedUid !== ""
                Material.background: "#8A3A3A"
                onClicked: removeConfirm.open()
            }
        }

        RowLayout {
            Layout.fillWidth: true
            Layout.fillHeight: true
            spacing: 24

            Rectangle {
                Layout.preferredWidth: 520
                Layout.fillHeight: true
                radius: 16
                color: controller.selectedAccent
                clip: true

                Image {
                    anchors.fill: parent
                    source: controller.selectedScreenshot
                    fillMode: Image.PreserveAspectCrop
                    visible: controller.selectedScreenshot !== ""
                    asynchronous: true
                }

                Image {
                    anchors.fill: parent
                    anchors.margins: 48
                    source: controller.selectedIcon
                    fillMode: Image.PreserveAspectFit
                    visible: controller.selectedScreenshot === "" && controller.selectedIcon !== ""
                    asynchronous: true
                }

                Column {
                    visible: controller.selectedScreenshot === "" && controller.selectedIcon === ""
                    anchors.centerIn: parent
                    spacing: 8
                    Text {
                        anchors.horizontalCenter: parent.horizontalCenter
                        text: controller.selectedInitial
                        color: "white"
                        font.family: Fonts.sans
                        font.pixelSize: 48
                        font.weight: Fonts.bold
                    }
                    Text {
                        anchors.horizontalCenter: parent.horizontalCenter
                        text: controller.selectedName
                        color: "#F4F7FB"
                        font.family: Fonts.sans
                        font.pixelSize: Fonts.heading
                        font.weight: Fonts.bold
                    }
                }
            }

            ColumnLayout {
                Layout.fillWidth: true
                Layout.fillHeight: true
                spacing: 10

                Label {
                    text: controller.selectedName
                    font.family: Fonts.sans
                    font.pixelSize: Fonts.heading
                    font.weight: Fonts.bold
                    color: "#F2F6FB"
                }
                Label {
                    text: controller.selectedSummary
                    font.family: Fonts.sans
                    font.pixelSize: Fonts.description
                    font.weight: Fonts.regular
                    color: "#C5D0DF"
                    wrapMode: Text.WordWrap
                    Layout.fillWidth: true
                }
                Label {
                    visible: controller.selectedRating > 0
                    text: "★ " + Number(controller.selectedRating).toFixed(1)
                    color: "#E8C547"
                    font.family: Fonts.sans
                    font.pixelSize: Fonts.rating
                    font.weight: Fonts.regular
                }
                Label {
                    visible: controller.selectedVersion !== ""
                    text: controller.selectedVersion
                    color: "#7E8B9A"
                    font.family: Fonts.mono
                    font.pixelSize: Fonts.monoSize
                    font.weight: Fonts.regular
                }
                Label {
                    text: controller.selectedInstalled ? "This application is installed." : "Not installed."
                    color: controller.selectedInstalled ? "#6FCFC6" : "#9AA8BA"
                    font.family: Fonts.sans
                    font.pixelSize: Fonts.status
                    font.weight: Fonts.medium
                }
                ScrollView {
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    Label {
                        width: parent.width
                        text: controller.selectedDescription
                        wrapMode: Text.WordWrap
                        textFormat: Text.PlainText
                        color: "#B7C4D2"
                        font.family: Fonts.sans
                        font.pixelSize: Fonts.description
                        font.weight: Fonts.regular
                    }
                }
            }
        }
    }
}
