from __future__ import annotations

from appgrid.backends.base import AppEntry

# Same buckets as the 2013 App Grid, plus Internet so browsers are not only in All.
GROUPS: tuple[tuple[str, str, frozenset[str]], ...] = (
    ("arts", "Arts", frozenset({"graphics", "art", "photography", "audiovideo", "audio", "video", "tv", "tuner"})),
    ("games", "Games", frozenset({"game", "games", "actiongame", "adventuregame", "arcadegame", "blocksgame", "boardgame", "cardgame", "kidsgame", "logicgame", "roleplaying", "shooter", "simulation", "sportsgame", "strategygame"})),
    ("productivity", "Productivity", frozenset({"office", "productivity", "wordprocessor", "spreadsheet", "presentation", "chart", "database", "finance", "projectmanagement", "email", "calendar", "contactmanagement"})),
    ("programming", "Programming", frozenset({"development", "ide", "debugger", "building", "revisioncontrol", "guidesigner", "webdevelopment"})),
    ("sciences", "Sciences", frozenset({"science", "education", "math", "numericalanalysis", "astronomy", "biology", "chemistry", "geology", "medicalsoftware", "physics"})),
    ("internet", "Internet", frozenset({"network", "webbrowser", "chat", "instantmessaging", "ircclient", "filetransfer", "p2p", "news", "hamradio"})),
    ("system", "System", frozenset({"system", "settings", "utility", "security", "packagemanager", "monitor", "filemanager", "terminalemulator", "accessibility"})),
)


def group_id(entry: AppEntry) -> str:
    tags = {item.lower() for item in (entry.categories or []) if item}
    for ident, _label, needles in GROUPS:
        if tags & needles:
            return ident
    return ""


def matches(entry: AppEntry, category: str) -> bool:
    if not category:
        return True
    return group_id(entry) == category


def present(entries: list[AppEntry]) -> list[dict[str, str]]:
    seen = {group_id(entry) for entry in entries}
    return [{"id": ident, "label": label} for ident, label, _needles in GROUPS if ident in seen]
