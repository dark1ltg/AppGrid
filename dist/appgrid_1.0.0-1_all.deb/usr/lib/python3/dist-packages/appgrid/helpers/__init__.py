"""Restricted root helpers."""
