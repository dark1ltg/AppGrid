"""App catalog helpers."""
